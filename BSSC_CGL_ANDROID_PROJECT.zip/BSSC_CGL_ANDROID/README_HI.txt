BSSC CGL MASTER — Android Studio प्रोजेक्ट

यह Android WebView wrapper है जो पहले बने HTML अभ्यास ऐप को Android ऐप के भीतर चलाता है।

APK बनाने के लिए:
1. Android Studio का वर्तमान stable संस्करण इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में इस फ़ोल्डर को Open करें।
4. Gradle sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. परीक्षण APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

सार्वजनिक वितरण:
- सार्वजनिक उपयोग के लिए release build बनाएं और अपनी निजी upload keystore से sign करें।
- Keystore और passwords सुरक्षित रखें; इन्हें किसी को साझा न करें।
- Play Store पर डालने के लिए Google Play Console developer account, store listing, privacy policy, app testing और वर्तमान Play requirements पूरी करनी होंगी।
- इस प्रोजेक्ट में अभी कोई सर्वर, ऑनलाइन प्रश्न सिंक, यूज़र अकाउंट या global leaderboard नहीं है। जो प्रश्न जोड़े जाते हैं वे उसी डिवाइस/ब्राउज़र के स्थानीय storage में रहते हैं।
- नमूना प्रश्न केवल शुरुआती अभ्यास के लिए हैं; सत्यापित PYQ होने का दावा नहीं है।

नोट: इस ZIP में Android source project है, compiled APK नहीं।
